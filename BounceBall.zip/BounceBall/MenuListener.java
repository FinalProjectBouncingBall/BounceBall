
package BounceBall;

import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.media.opengl.GLEventListener;



  

public abstract class MenuListener implements GLEventListener, KeyListener ,MouseMotionListener,MouseListener
     {
 
    protected String assetsFolderName = "BounceBall";

   
    
}

